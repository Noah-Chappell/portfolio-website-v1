Points:
readme
    -done
content
    -Appropriate headings and paragraph text
    -Links to external page(s)
styling
    -Modifying padding and margins to indent content and enhance readability
    -Modifying link, text color, or other colors to be visually appealing, perhaps with one of the pallette creators in the Resources section.
    -Adding custom font(s) from Google fonts to add more personality (make sure to include appropriate fallbacks)
advanced feature
    -Creating a more complex page layout, such as including a sidebar or navigation bar
responsive
    -done
validation
    -had an error for a fun toggle switch I was trying, didn't know that you werent allowed to put a div inside of a label. Didn't have time to fix, I really like how it works right now but I will fix it later.
    -had some errors with it not wanting me to use the scale shorthand will fix no time

embracing spirit
    -done